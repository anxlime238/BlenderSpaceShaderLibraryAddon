bl_info = {
    "name": "Space Shader Library",
    "author": "AntipovaKuznetsov",
    "version": (1, 0),
    "blender": (2, 91, 0),
    "location": "View3D > ToolShelf",
    "description": "Adds a new Shader to an object",
    "warning": "",
    "doc_url": "https://github.com/DontTryToHackMe/BlenderSpaceShaderLibraryAddon",
    "category": "Add Shader",
}

import bpy

class ShaderMainPanel(bpy.types.Panel):
    bl_label = "Space Shader Library"
    bl_idname = "SHADER_PT_MAINPANEL"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Shader Library'

    def draw(self, context):
        layout = self.layout
        
        row = layout.row()
        row.label(text = "Choose an object in 3D viewport, then choose a material", icon = 'FILE')
               
#Создаем панель с материалами планет       
class PlanetsPanel(bpy.types.Panel):
    bl_label = "Planet Materials"
    bl_idname = "SHADER_PT_PlanetsPanel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Shader Library'

    def draw(self, context):
        layout = self.layout
        
        row = layout.row()
        row.label(text = "Select Shader", icon = 'SHADING_RENDERED')
        row = layout.row()

        row.operator('shader.moon_operator') 
        row.operator('shader.lava_operator') 
        row.operator('shader.mustafar_operator')
        row.operator('shader.desert_operator')
        row = layout.row()
        row.operator('shader.gas_operator')
        row.operator('shader.water_operator')
        row.operator('shader.salt_operator')
        
#Создаем панель с остальными материалами        
class AllMatPanel(bpy.types.Panel):
    bl_label = "Other Materials"
    bl_idname = "SHADER_PT_AllMatPanel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Shader Library'

    def draw(self, context):
        layout = self.layout
        
        row = layout.row()
        row.label(text = "Select Shader", icon = 'SHADING_TEXTURE')
        row = layout.row()
        row.operator('shader.glass_operator')
        row.operator('shader.rubber_operator')
        row.operator('shader.rustedmetal_operator')
            
#Создание первого материала - Луна
class SHADER_OT_MOON(bpy.types.Operator):
    bl_label = "Moon"
    bl_idname = 'shader.moon_operator'
    
    def execute(self, context):
            
        material_moon = bpy.data.materials.new(name = "Moon")
        material_moon.cycles.displacement_method = 'BOTH'
        #Включение нодовой системы
        material_moon.use_nodes = True
        #Удаление стандартной ноды Principled BSDF
        material_moon.node_tree.nodes.remove(material_moon.node_tree.nodes.get('Principled BSDF'))
        
        #Настройка каждой ноды
        material_output = material_moon.node_tree.nodes.get('Material Output')
        material_output.location = (300, 0)
        
        diffuse_node = material_moon.node_tree.nodes.new('ShaderNodeBsdfDiffuse')
        diffuse_node.location = (100,60)
        diffuse_node.inputs[0].default_value = (0.171, 0.157, 0.137, 1)
        diffuse_node.inputs[1].default_value = 0.608
        
        voronoiTex_node = material_moon.node_tree.nodes.new('ShaderNodeTexVoronoi')
        voronoiTex_node.location = (100,-60)
        voronoiTex_node.feature = 'DISTANCE_TO_EDGE'
        voronoiTex_node.inputs[2].default_value = 0.3
        noiseTex_node = material_moon.node_tree.nodes.new('ShaderNodeTexNoise')
        noiseTex_node.location = (-100,-120)
        noiseTex_node.inputs[2].default_value = 4
        noiseTex_node.inputs[3].default_value = 10.7
        noiseTex_node.inputs[4].default_value = 0.492
        
        #Создание связей между нодами
        material_moon.node_tree.links.new(diffuse_node.outputs[0], material_output.inputs[0])
        material_moon.node_tree.links.new(voronoiTex_node.outputs[0], material_output.inputs[2])
        material_moon.node_tree.links.new(noiseTex_node.outputs[1], voronoiTex_node.inputs[0])
        
        bpy.context.object.active_material = material_moon
        
        return{'FINISHED'}
    
#Создание материала - Лавовая планета
#По аналогии с первым материалом во всех последующих включается нодовая система, 
#затем настраивается каждая нода отдельно, создаются линки между ними
class SHADER_OT_LAVA(bpy.types.Operator):
    bl_label = "Lava"
    bl_idname = 'shader.lava_operator'
    
    def execute(self, context):
            
        material_lava = bpy.data.materials.new(name = "Lava")

        material_lava.use_nodes = True

        principled_bsdf_node = material_lava.node_tree.nodes.get('Principled BSDF')
        principled_bsdf_node.inputs[0].default_value = (0.028, 0.025, 0.023, 1)
        principled_bsdf_node.inputs[7].default_value = 0.673
        principled_bsdf_node.location = (100, 0)
        
        material_output = material_lava.node_tree.nodes.get('Material Output')
        material_output.location = (800, 0)
        
        noiseTex_node = material_lava.node_tree.nodes.new('ShaderNodeTexNoise')
        noiseTex_node.location = (-300,-0)
        noiseTex_node.inputs[2].default_value = 3.4
        noiseTex_node.inputs[3].default_value = 16
        noiseTex_node.inputs[4].default_value = 0.658
        noiseTex_node.inputs[5].default_value = 0.3
        
        bump_node = material_lava.node_tree.nodes.new('ShaderNodeBump')
        bump_node.location = (-100, -300)
        
        colorRamp_node = material_lava.node_tree.nodes.new('ShaderNodeValToRGB')
        colorRamp_node.location = (100, 300)
        colorRamp_node.color_ramp.elements[0].position = 0.518
        colorRamp_node.color_ramp.elements[1].position = 0.81
        
        emission_node = material_lava.node_tree.nodes.new('ShaderNodeEmission')
        emission_node.location = (400, -200)
        emission_node.inputs[0].default_value = (0.709, 0.017, 0.005, 1)
        emission_node.inputs[1].default_value = 28.2
        
        mix_node = material_lava.node_tree.nodes.new('ShaderNodeMixShader')
        mix_node.location = (500, 0)
        
        mapping_node = material_lava.node_tree.nodes.new('ShaderNodeMapping')
        mapping_node.location = (-500, 0)
        
        tex_coord_node = material_lava.node_tree.nodes.new('ShaderNodeTexCoord')
        tex_coord_node.location = (-700, 0)
        
        material_lava.node_tree.links.new(tex_coord_node.outputs[3], mapping_node.inputs[0])
        material_lava.node_tree.links.new(mapping_node.outputs[0], noiseTex_node.inputs[0])
        material_lava.node_tree.links.new(noiseTex_node.outputs[1], bump_node.inputs[2])
        material_lava.node_tree.links.new(noiseTex_node.outputs[1], colorRamp_node.inputs[0])
        material_lava.node_tree.links.new(colorRamp_node.outputs[0], mix_node.inputs[0])
        material_lava.node_tree.links.new(mix_node.outputs[0], material_output.inputs[0])
        material_lava.node_tree.links.new(bump_node.outputs[0], principled_bsdf_node.inputs[20])
        material_lava.node_tree.links.new(principled_bsdf_node.outputs[0], mix_node.inputs[1])
        material_lava.node_tree.links.new(emission_node.outputs[0], mix_node.inputs[2])
        
        bpy.context.object.active_material = material_lava
        
        return{'FINISHED'}    
    
#Создание материала - планета Мустафар
class SHADER_OT_MUSTAFAR(bpy.types.Operator):
    bl_label = "Mustafar"
    bl_idname = 'shader.mustafar_operator'
    
    def execute(self, context):
            
        material_mustafar = bpy.data.materials.new(name = "mustafar")

        material_mustafar.use_nodes = True
        
        principled_bsdf_node = material_mustafar.node_tree.nodes.get('Principled BSDF')
        principled_bsdf_node.inputs[5].default_value = 1
        principled_bsdf_node.inputs[6].default_value = 1
        principled_bsdf_node.inputs[7].default_value = 0.8
        principled_bsdf_node.location = (100, 0)
        
        mix_node = material_mustafar.node_tree.nodes.new('ShaderNodeMixShader')
        mix_node.location = (600, 0)
        
        material_output = material_mustafar.node_tree.nodes.get('Material Output')
        material_output.location = (800, 0)
        
        emission_node = material_mustafar.node_tree.nodes.new('ShaderNodeEmission')
        emission_node.location = (200, -650)
        emission_node.inputs[1].default_value = 1.9
        
        colorRamp1_node = material_mustafar.node_tree.nodes.new('ShaderNodeValToRGB')
        colorRamp1_node.location = (-400, -600)
        colorRamp1_node.color_ramp.elements[0].position = 0.568
        colorRamp1_node.color_ramp.elements[0].color = (0, 0, 0, 1)
        colorRamp1_node.color_ramp.elements[1].position = 0.964
        colorRamp1_node.color_ramp.elements[1].color = (0.693, 0.030, 0.024, 1)
        colorRamp1_node.color_ramp.elements.new(1)
        colorRamp1_node.color_ramp.elements[2].color = (0.696, 0.130, 0.017, 1)
        
        musgraveTex1_node = material_mustafar.node_tree.nodes.new('ShaderNodeTexMusgrave')
        musgraveTex1_node.location = (-750,-600)
        musgraveTex1_node.inputs[2].default_value = 1
        musgraveTex1_node.inputs[3].default_value = 9.5
        musgraveTex1_node.inputs[4].default_value = 0.1
        
        musgraveTex2_node = material_mustafar.node_tree.nodes.new('ShaderNodeTexMusgrave')
        musgraveTex2_node.location = (-750,-200)
        musgraveTex2_node.inputs[2].default_value = 1
        musgraveTex2_node.inputs[3].default_value = 16
        musgraveTex2_node.inputs[4].default_value = 0
        
        colorRamp2_node = material_mustafar.node_tree.nodes.new('ShaderNodeValToRGB')
        colorRamp2_node.location = (-400, -200)
        colorRamp2_node.color_ramp.elements[1].position = 0.659
        
        bump_node = material_mustafar.node_tree.nodes.new('ShaderNodeBump')
        bump_node.location = (-100, -300)
        
        musgraveTex3_node = material_mustafar.node_tree.nodes.new('ShaderNodeTexMusgrave')
        musgraveTex3_node.location = (-750, 100)
        musgraveTex3_node.inputs[2].default_value = 1
        musgraveTex3_node.inputs[3].default_value = 16
        musgraveTex3_node.inputs[4].default_value = 0
        
        colorRamp3_node = material_mustafar.node_tree.nodes.new('ShaderNodeValToRGB')
        colorRamp3_node.location = (-400, 100)
        colorRamp3_node.color_ramp.interpolation = 'CONSTANT'
        colorRamp3_node.color_ramp.elements[0].color = (0.024, 0.006, 0.003, 1)
        colorRamp3_node.color_ramp.elements[1].position = 0.659
        colorRamp3_node.color_ramp.elements[1].color = (0.172, 0.046, 0.022, 1)
        
        material_mustafar.node_tree.links.new(musgraveTex3_node.outputs[0], colorRamp3_node.inputs[0])
        material_mustafar.node_tree.links.new(colorRamp3_node.outputs[0], principled_bsdf_node.inputs[0])
        material_mustafar.node_tree.links.new(principled_bsdf_node.outputs[0], mix_node.inputs[1])
        material_mustafar.node_tree.links.new(mix_node.outputs[0], material_output.inputs[0])
        material_mustafar.node_tree.links.new(musgraveTex2_node.outputs[0], colorRamp2_node.inputs[0])
        material_mustafar.node_tree.links.new(colorRamp2_node.outputs[0], bump_node.inputs[2])
        material_mustafar.node_tree.links.new(bump_node.outputs[0], principled_bsdf_node.inputs[20])
        material_mustafar.node_tree.links.new(musgraveTex1_node.outputs[0], colorRamp1_node.inputs[0])
        material_mustafar.node_tree.links.new(colorRamp1_node.outputs[0], emission_node.inputs[0])
        material_mustafar.node_tree.links.new(emission_node.outputs[0], mix_node.inputs[2])
        
      
        bpy.context.object.active_material = material_mustafar
        
        return{'FINISHED'}    
    
#Создание материала - Пустынная планета
class SHADER_OT_DESERT(bpy.types.Operator):
    bl_label = "Desert"
    bl_idname = 'shader.desert_operator'
    
    def execute(self, context):
            
        material_desert = bpy.data.materials.new(name = "desert")

        material_desert.use_nodes = True

        principled_bsdf_node = material_desert.node_tree.nodes.get('Principled BSDF')
        principled_bsdf_node.inputs[5].default_value = 0.755
        principled_bsdf_node.inputs[6].default_value = 1
        principled_bsdf_node.inputs[7].default_value = 0.8
        principled_bsdf_node.location = (100, 0)

        material_output = material_desert.node_tree.nodes.get('Material Output')
        material_output.location = (800, 0)
        
        musgraveTex_node = material_desert.node_tree.nodes.new('ShaderNodeTexMusgrave')
        musgraveTex_node.location = (-750,-200)
        musgraveTex_node.inputs[2].default_value = 4.9
        musgraveTex_node.inputs[3].default_value = 10.4
        musgraveTex_node.inputs[4].default_value = 0.2
        
        colorRamp1_node = material_desert.node_tree.nodes.new('ShaderNodeValToRGB')
        colorRamp1_node.location = (-400, -200)
        colorRamp1_node.color_ramp.interpolation = 'B_SPLINE'
        colorRamp1_node.color_ramp.elements[0].color = (0.113, 0.02, 0.008, 1)
        colorRamp1_node.color_ramp.elements[1].position = 0.141
        colorRamp1_node.color_ramp.elements[1].color = (0.716, 0.175, 0.074, 1)
        
        colorRamp2_node = material_desert.node_tree.nodes.new('ShaderNodeValToRGB')
        colorRamp2_node.location = (-400, -600)
        colorRamp2_node.color_ramp.interpolation = 'EASE'
        colorRamp2_node.color_ramp.elements[1].position = 0.305
        colorRamp2_node.color_ramp.elements[1].color = (1, 0.855, 0.905, 1)
        
        bump_node = material_desert.node_tree.nodes.new('ShaderNodeBump')
        bump_node.location = (-100, -550)
        bump_node.invert = True
        bump_node.inputs[1].default_value = 11.1
        
        material_desert.node_tree.links.new(musgraveTex_node.outputs[0], colorRamp1_node.inputs[0])
        material_desert.node_tree.links.new(musgraveTex_node.outputs[0], colorRamp2_node.inputs[0])
        material_desert.node_tree.links.new(colorRamp1_node.outputs[0], principled_bsdf_node.inputs[0])
        material_desert.node_tree.links.new(colorRamp2_node.outputs[0], bump_node.inputs[2])
        material_desert.node_tree.links.new(bump_node.outputs[0], principled_bsdf_node.inputs[20])
        material_desert.node_tree.links.new(principled_bsdf_node.outputs[0], material_output.inputs[0])
      
        bpy.context.object.active_material = material_desert
        
        return{'FINISHED'}
        
#Создание материала - Газовый гигант
class SHADER_OT_GAS(bpy.types.Operator):
    bl_label = "Gas Giant"
    bl_idname = 'shader.gas_operator'
    
    def execute(self, context):
            
        material_gas = bpy.data.materials.new(name = "gas")

        material_gas.use_nodes = True

        principled_bsdf_node = material_gas.node_tree.nodes.get('Principled BSDF')
        principled_bsdf_node.inputs[5].default_value = 1
        principled_bsdf_node.inputs[6].default_value = 1
        principled_bsdf_node.inputs[7].default_value = 0.682
        principled_bsdf_node.location = (100, 0)

        material_output = material_gas.node_tree.nodes.get('Material Output')
        material_output.location = (500, 0)
        
        coordTex_node = material_gas.node_tree.nodes.new('ShaderNodeTexCoord')
        coordTex_node.location = (-1550,-200)
        
        mapping_node = material_gas.node_tree.nodes.new('ShaderNodeMapping')
        mapping_node.location = (-1350,-200)
        mapping_node.inputs[1].default_value[0] = 0.5
        mapping_node.inputs[2].default_value[1] = 1.570796
        mapping_node.inputs[3].default_value[2] = 0.4
        
        gradientTex_node = material_gas.node_tree.nodes.new('ShaderNodeTexGradient')
        gradientTex_node.location = (-1120, -100)
        
        noiseTex1_node = material_gas.node_tree.nodes.new('ShaderNodeTexNoise')
        noiseTex1_node.location = (-1120, -350)
        noiseTex1_node.inputs[2].default_value = 35.5
        noiseTex1_node.inputs[3].default_value = 16
        noiseTex1_node.inputs[4].default_value = 0.417
        
        mix_node = material_gas.node_tree.nodes.new('ShaderNodeMixRGB')
        mix_node.location = (-900, -100)
        mix_node.inputs[0].default_value = 0.005
        
        noiseTex2_node = material_gas.node_tree.nodes.new('ShaderNodeTexNoise')
        noiseTex2_node.location = (-650, -150)
        noiseTex2_node.noise_dimensions = '4D'
        noiseTex2_node.inputs[2].default_value = 6.4
        noiseTex2_node.inputs[3].default_value = 5.9
        noiseTex2_node.inputs[4].default_value = 0.525
        noiseTex2_node.inputs[5].default_value = -0.7
        
        colorRamp_node = material_gas.node_tree.nodes.new('ShaderNodeValToRGB')
        colorRamp_node.location = (-400, -200)
        colorRamp_node.color_ramp.elements[0].position = 0.373
        colorRamp_node.color_ramp.elements[0].color = (0.529, 0.447, 0.370, 1)
        colorRamp_node.color_ramp.elements[1].position = 0.470
        colorRamp_node.color_ramp.elements[1].color = (0.403, 0.259, 0.168, 1)
        colorRamp_node.color_ramp.elements.new(0.523)
        colorRamp_node.color_ramp.elements[2].color = (0.574, 0.234, 0.125, 1)
        colorRamp_node.color_ramp.elements.new(0.582)
        colorRamp_node.color_ramp.elements[3].color = (0.206, 0.070, 0.059, 1)
        
        bump_node = material_gas.node_tree.nodes.new('ShaderNodeBump')
        bump_node.location = (-100, -550)
        
        bump_node.inputs[0].default_value = 0.342
        bump_node.inputs[1].default_value = 0.3
        
        material_gas.node_tree.links.new(coordTex_node.outputs[3], mapping_node.inputs[0])
        material_gas.node_tree.links.new(mapping_node.outputs[0], gradientTex_node.inputs[0])
        material_gas.node_tree.links.new(gradientTex_node.outputs[1], mix_node.inputs[1])
        material_gas.node_tree.links.new(noiseTex1_node.outputs[0], mix_node.inputs[2])
        material_gas.node_tree.links.new(mix_node.outputs[0], noiseTex2_node.inputs[0])
        material_gas.node_tree.links.new(noiseTex2_node.outputs[1], colorRamp_node.inputs[0])
        material_gas.node_tree.links.new(colorRamp_node.outputs[0], principled_bsdf_node.inputs[0])
        material_gas.node_tree.links.new(colorRamp_node.outputs[0], bump_node.inputs[2])
        material_gas.node_tree.links.new(bump_node.outputs[0], principled_bsdf_node.inputs[20])
        material_gas.node_tree.links.new(principled_bsdf_node.outputs[0], material_output.inputs[0])
        
        bpy.context.object.active_material = material_gas
        
        return{'FINISHED'}
    
#Создание материала - Водная планета
class SHADER_OT_WATER(bpy.types.Operator):
    bl_label = "Water Planet"
    bl_idname = 'shader.water_operator'
    
    def execute(self, context):
            
        material_water = bpy.data.materials.new(name = "water")

        material_water.use_nodes = True

        principled_bsdf_node = material_water.node_tree.nodes.get('Principled BSDF')
        principled_bsdf_node.inputs[5].default_value = 1
        principled_bsdf_node.inputs[6].default_value = 1
        principled_bsdf_node.inputs[7].default_value = 0.682
        principled_bsdf_node.location = (100, 0)

        material_output = material_water.node_tree.nodes.get('Material Output')
        material_output.location = (500, 50)
        
        coordTex_node = material_water.node_tree.nodes.new('ShaderNodeTexCoord')
        coordTex_node.location = (-1200,-150)
        
        mapping_node = material_water.node_tree.nodes.new('ShaderNodeMapping')
        mapping_node.location = (-850,-150)
        
        noiseTex_node = material_water.node_tree.nodes.new('ShaderNodeTexNoise')
        noiseTex_node.location = (-600, -300)
        noiseTex_node.inputs[2].default_value = 2.6
        noiseTex_node.inputs[3].default_value = 16
        noiseTex_node.inputs[5].default_value = 0.1
        
        colorRamp1_node = material_water.node_tree.nodes.new('ShaderNodeValToRGB')
        colorRamp1_node.location = (-400, -80)
        colorRamp1_node.color_ramp.elements[0].position = 0.286
        colorRamp1_node.color_ramp.elements[0].color = (0.226, 0.135, 0.082, 1)
        colorRamp1_node.color_ramp.elements[1].position = 0.350
        colorRamp1_node.color_ramp.elements[1].color = (0.210, 0.064, 0.037, 1)
        colorRamp1_node.color_ramp.elements.new(0.496)
        colorRamp1_node.color_ramp.elements[2].color = (0.326, 0.358, 0.043, 1)
        colorRamp1_node.color_ramp.elements.new(0.559)
        colorRamp1_node.color_ramp.elements[3].color = (0.063, 0.165, 0.405, 1)
        colorRamp1_node.color_ramp.elements.new(0.605)
        colorRamp1_node.color_ramp.elements[4].color = (0.021, 0.066, 0.374, 1)
        
        colorRamp2_node = material_water.node_tree.nodes.new('ShaderNodeValToRGB')
        colorRamp2_node.location = (-400, -450)
        colorRamp2_node.color_ramp.elements[0].position = 0.364
        colorRamp2_node.color_ramp.elements[1].position = 0.556

        bump_node = material_water.node_tree.nodes.new('ShaderNodeBump')
        bump_node.location = (-100, -550)
        bump_node.invert = True
        bump_node.inputs[0].default_value = 0.883
        bump_node.inputs[1].default_value = 2.2
        
        
        material_water.node_tree.links.new(coordTex_node.outputs[3], mapping_node.inputs[0])
        material_water.node_tree.links.new(mapping_node.outputs[0], noiseTex_node.inputs[0])
        material_water.node_tree.links.new(noiseTex_node.outputs[1], colorRamp1_node.inputs[0])
        material_water.node_tree.links.new(noiseTex_node.outputs[1], colorRamp2_node.inputs[0])
        material_water.node_tree.links.new(colorRamp1_node.outputs[0], principled_bsdf_node.inputs[0])
        material_water.node_tree.links.new(colorRamp2_node.outputs[0], bump_node.inputs[2])
        material_water.node_tree.links.new(bump_node.outputs[0], principled_bsdf_node.inputs[20])
        material_water.node_tree.links.new(principled_bsdf_node.outputs[0], material_output.inputs[0])
        
        bpy.context.object.active_material = material_water
        
        return{'FINISHED'}
    
#Создание материала - Солевая планета
class SHADER_OT_SALT(bpy.types.Operator):
    bl_label = "Salt Planet"
    bl_idname = 'shader.salt_operator'
    
    def execute(self, context):
            
        material_salt = bpy.data.materials.new(name = "salt")

        material_salt.use_nodes = True

        principled_bsdf_node = material_salt.node_tree.nodes.get('Principled BSDF')
        principled_bsdf_node.inputs[5].default_value = 1
        principled_bsdf_node.inputs[6].default_value = 1
        principled_bsdf_node.inputs[7].default_value = 0.682
        principled_bsdf_node.location = (100, 0)

        material_output = material_salt.node_tree.nodes.get('Material Output')
        material_output.location = (500, 50)
        
        coordTex_node = material_salt.node_tree.nodes.new('ShaderNodeTexCoord')
        coordTex_node.location = (-1200,-150)
        
        mapping_node = material_salt.node_tree.nodes.new('ShaderNodeMapping')
        mapping_node.location = (-850,-150)
        
        noiseTex_node = material_salt.node_tree.nodes.new('ShaderNodeTexNoise')
        noiseTex_node.location = (-600, -300)
        noiseTex_node.inputs[2].default_value = 3.2
        noiseTex_node.inputs[3].default_value = 16
        noiseTex_node.inputs[4].default_value = 0.758
        noiseTex_node.inputs[5].default_value = 0.1
        
        colorRamp1_node = material_salt.node_tree.nodes.new('ShaderNodeValToRGB')
        colorRamp1_node.location = (-400, -80)
        colorRamp1_node.color_ramp.elements[0].position = 0.405
        colorRamp1_node.color_ramp.elements[0].color = (0.271, 0.019, 0.011, 1)
        colorRamp1_node.color_ramp.elements[1].position = 0.482
        colorRamp1_node.color_ramp.elements[1].color = (1, 0.956, 0.885, 1)
        colorRamp1_node.color_ramp.elements.new(0.527)
        colorRamp1_node.color_ramp.elements[2].color = (0.757, 0.027, 0.022, 1)
        
        colorRamp2_node = material_salt.node_tree.nodes.new('ShaderNodeValToRGB')
        colorRamp2_node.location = (-400, -450)
        colorRamp2_node.color_ramp.elements[0].position = 0.373
        colorRamp2_node.color_ramp.elements[1].position = 0.541

        bump_node = material_salt.node_tree.nodes.new('ShaderNodeBump')
        bump_node.location = (-100, -550)
        bump_node.inputs[0].default_value = 0.492
        bump_node.inputs[1].default_value = 3.3
        
        
        material_salt.node_tree.links.new(coordTex_node.outputs[3], mapping_node.inputs[0])
        material_salt.node_tree.links.new(mapping_node.outputs[0], noiseTex_node.inputs[0])
        material_salt.node_tree.links.new(noiseTex_node.outputs[1], colorRamp1_node.inputs[0])
        material_salt.node_tree.links.new(noiseTex_node.outputs[1], colorRamp2_node.inputs[0])
        material_salt.node_tree.links.new(colorRamp1_node.outputs[0], principled_bsdf_node.inputs[0])
        material_salt.node_tree.links.new(colorRamp2_node.outputs[0], bump_node.inputs[2])
        material_salt.node_tree.links.new(bump_node.outputs[0], principled_bsdf_node.inputs[20])
        material_salt.node_tree.links.new(principled_bsdf_node.outputs[0], material_output.inputs[0])
        
        bpy.context.object.active_material = material_salt
        
        return{'FINISHED'}
    
#Создание материала - Стекло
class SHADER_OT_GLASS(bpy.types.Operator):
    bl_label = "Glass"
    bl_idname = 'shader.glass_operator'
    
    def execute(self, context):
            
        material_glass = bpy.data.materials.new(name = "Glass")
        
        material_glass.use_nodes = True

        material_glass.node_tree.nodes.remove(material_glass.node_tree.nodes.get('Principled BSDF'))
        
        material_output = material_glass.node_tree.nodes.get('Material Output')
        material_output.location = (300, 0)
        
        glass_node = material_glass.node_tree.nodes.new('ShaderNodeBsdfGlass')
        glass_node.location = (100,0)
        glass_node.inputs[0].default_value = (0.8302, 0.9886, 1, 1)
        glass_node.inputs[1].default_value = 0.1
        glass_node.inputs[2].default_value = 1.150
        
        
        material_glass.node_tree.links.new(glass_node.outputs[0], material_output.inputs[0])
        
        bpy.context.object.active_material = material_glass
        
        return{'FINISHED'}
        
#Создание материала - Резина
class SHADER_OT_RUBBER(bpy.types.Operator):
    bl_label = "Rubber"
    bl_idname = 'shader.rubber_operator'
    
    def execute(self, context):
            
        material_rubber = bpy.data.materials.new(name = "Rubber")

        material_rubber.use_nodes = True

        material_rubber.node_tree.nodes.remove(material_rubber.node_tree.nodes.get('Principled BSDF'))
        
        material_output = material_rubber.node_tree.nodes.get('Material Output')
        material_output.location = (300, 0)
        
        diffuse_node = material_rubber.node_tree.nodes.new('ShaderNodeBsdfDiffuse')
        diffuse_node.location = (100,0)
        diffuse_node.inputs[0].default_value = (0.00416, 0.00416, 0.00416, 1)
        diffuse_node.inputs[1].default_value = 1
        
        
        material_rubber.node_tree.links.new(diffuse_node.outputs[0], material_output.inputs[0])
        
        bpy.context.object.active_material = material_rubber
        
        return{'FINISHED'}
    
#Создание материала - Ржавый металл
class SHADER_OT_RUSTEDMETAL(bpy.types.Operator):
    bl_label = "Rustedmetal"
    bl_idname = 'shader.rustedmetal_operator'
    
    def execute(self, context):
            
        material_rustedmetal = bpy.data.materials.new(name = "Rustedmetal")
        
        material_rustedmetal.use_nodes = True
        
        material_output = material_rustedmetal.node_tree.nodes.get('Material Output')
        material_output.location = (400, 0)
        
        principledBSDF_node = material_rustedmetal.node_tree.nodes.get('Principled BSDF')
        principledBSDF_node.location = (100, 0)
        principledBSDF_node.inputs[4].default_value = 1
        
        bump1_node = material_rustedmetal.node_tree.nodes.new('ShaderNodeBump')
        bump1_node.location = (-100, -500)
        bump1_node.inputs[0].default_value = 0.65
        bump1_node.inputs[1].default_value = 0.1
        
        bump2_node = material_rustedmetal.node_tree.nodes.new('ShaderNodeBump')
        bump2_node.location = (-250, -700)
        bump2_node.inputs[0].default_value = 0.05
        bump2_node.inputs[1].default_value = 0.1
        
        noiseTex2_node = material_rustedmetal.node_tree.nodes.new('ShaderNodeTexNoise')
        noiseTex2_node.location = (-420, -700)
        noiseTex2_node.inputs[2].default_value = 50
        noiseTex2_node.inputs[3].default_value = 16
        
        noiseTex3_node = material_rustedmetal.node_tree.nodes.new('ShaderNodeTexNoise')
        noiseTex3_node.location = (-600, -750)
        noiseTex3_node.inputs[2].default_value = 20
        noiseTex3_node.inputs[3].default_value = 16
        
        colorRamp1_node = material_rustedmetal.node_tree.nodes.new('ShaderNodeValToRGB')
        colorRamp1_node.location = (-400, -450)
        colorRamp1_node.color_ramp.elements[1].position = 0.47
        
        noiseTex1_node = material_rustedmetal.node_tree.nodes.new('ShaderNodeTexNoise')
        noiseTex1_node.location = (-600, -500)
        noiseTex1_node.inputs[2].default_value = 5
        noiseTex1_node.inputs[3].default_value = 16
        
        mapping_node = material_rustedmetal.node_tree.nodes.new('ShaderNodeMapping')
        mapping_node.location = (-800, -500)
        
        texCoord_node = material_rustedmetal.node_tree.nodes.new('ShaderNodeTexCoord')
        texCoord_node.location = (-1000, -500)
        
        colorRamp2_node = material_rustedmetal.node_tree.nodes.new('ShaderNodeValToRGB')
        colorRamp2_node.location = (-300, -200)
        colorRamp2_node.color_ramp.elements.new(0.355)
        colorRamp2_node.color_ramp.elements[1].color = (0.023, 0.009, 0.006, 1)
        colorRamp2_node.color_ramp.elements.new(0.473)
        colorRamp2_node.color_ramp.elements[2].color = (0.358, 0.049, 0.024, 1)
        colorRamp2_node.color_ramp.elements.new(0.509)
        colorRamp2_node.color_ramp.elements[3].color = (0.039, 0.045, 0.05, 1)
        colorRamp2_node.color_ramp.elements.remove(colorRamp2_node.color_ramp.elements[4])
        
        material_rustedmetal.node_tree.links.new(texCoord_node.outputs[3], mapping_node.inputs[0])
        material_rustedmetal.node_tree.links.new(mapping_node.outputs[0], noiseTex1_node.inputs[0])
        material_rustedmetal.node_tree.links.new(noiseTex1_node.outputs[1], colorRamp1_node.inputs[0])
        material_rustedmetal.node_tree.links.new(noiseTex1_node.outputs[1], colorRamp2_node.inputs[0])
        material_rustedmetal.node_tree.links.new(bump2_node.outputs["Normal"], bump1_node.inputs["Normal"])
        material_rustedmetal.node_tree.links.new(colorRamp1_node.outputs[0], bump1_node.inputs[2])
        material_rustedmetal.node_tree.links.new(bump1_node.outputs[0], principledBSDF_node.inputs[20])
        material_rustedmetal.node_tree.links.new(principledBSDF_node.outputs[0], material_output.inputs[0])
        material_rustedmetal.node_tree.links.new(noiseTex3_node.outputs[1], noiseTex2_node.inputs[0])
        material_rustedmetal.node_tree.links.new(noiseTex2_node.outputs[1], bump2_node.inputs[2])
        material_rustedmetal.node_tree.links.new(colorRamp2_node.outputs[0], principledBSDF_node.inputs[0])
        
        bpy.context.object.active_material = material_rustedmetal
        
        return{'FINISHED'}
        
        
           
#Регистрация операторов всех материалов в системе
def register():
    bpy.utils.register_class(ShaderMainPanel)
    bpy.utils.register_class(PlanetsPanel)
    bpy.utils.register_class(AllMatPanel)
    bpy.utils.register_class(SHADER_OT_GLASS)
    bpy.utils.register_class(SHADER_OT_RUBBER)
    bpy.utils.register_class(SHADER_OT_RUSTEDMETAL)
    bpy.utils.register_class(SHADER_OT_MOON)
    bpy.utils.register_class(SHADER_OT_LAVA)
    bpy.utils.register_class(SHADER_OT_MUSTAFAR)
    bpy.utils.register_class(SHADER_OT_DESERT)
    bpy.utils.register_class(SHADER_OT_GAS)
    bpy.utils.register_class(SHADER_OT_WATER)
    bpy.utils.register_class(SHADER_OT_SALT)
    
def unregister():
    bpy.utils.unregister_class(ShaderMainPanel)
    bpy.utils.unregister_class(PlanetsPanel)
    bpy.utils.unregister_class(AllMatPanel)
    bpy.utils.unregister_class(SHADER_OT_GLASS)
    bpy.utils.unregister_class(SHADER_OT_RUBBER)
    bpy.utils.unregister_class(SHADER_OT_RUSTEDMETAL)
    bpy.utils.unregister_class(SHADER_OT_MOON)
    bpy.utils.unregister_class(SHADER_OT_LAVA)
    bpy.utils.unregister_class(SHADER_OT_MUSTAFAR)
    bpy.utils.unregister_class(SHADER_OT_DESERT)
    bpy.utils.unregister_class(SHADER_OT_GAS)
    bpy.utils.unregister_class(SHADER_OT_WATER)
    bpy.utils.unregister_class(SHADER_OT_SALT)


if __name__ == "__main__":
    register()
